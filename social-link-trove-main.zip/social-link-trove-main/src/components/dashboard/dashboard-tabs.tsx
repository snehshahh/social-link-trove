import { Inbox, Star, LinkIcon, Folder, Plus, BookOpen, FolderPlus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { LinkCard } from "./link-card";
import { EmptyState } from "./empty-state";
import { Link } from "@/types/link";
import { Collection } from "@/types/collection";
import { useDispatch, useSelector } from 'react-redux';
import { toggleImportant, togglePublic, deleteLink } from '@/store/slices/linksSlice';
import { setShowSharePopup, setShowPublicConfirmation } from '@/store/slices/uiSlice';

interface CollectionInterface {
  id: string;
  name: string;
  linkCount: number;
  dateCreated: string;
}

interface DashboardTabsProps {
  activeTab: string;
  onTabChange: (value: string) => void;
  links: Link[];
  collections: CollectionInterface[];
  searchQuery?: string;
  onDeleteLink: (id: string) => void;
  onToggleImportant: (id: string) => void;
  onTogglePublic: (id: string) => void;
  onShareLink: (id: string) => void;
  onUpdateNotes: (id: string, notes: string) => void;
  onSaveToCollection: (linkId: string, collectionId: string) => void;
  onRemoveFromCollection: (collectionId: string, linkId: string) => void;
}

export function DashboardTabs({
  activeTab,
  onTabChange,
  links = [],
  collections = [],
  searchQuery = "",
  onDeleteLink,
  onToggleImportant,
  onTogglePublic,
  onShareLink,
  onUpdateNotes,
  onSaveToCollection,
  onRemoveFromCollection,
}: DashboardTabsProps) {
  const dispatch = useDispatch();

  // Add safety check to ensure links is an array before filtering
  const linksArray = Array.isArray(links) ? links : [];
  console.log('DashboardTabs received links:', linksArray);
  
  // If no links are provided, use some fallback data for development
  if (linksArray.length === 0) {
    console.log('No links provided, using fallback data');
  }

  const filteredLinks = linksArray.filter(link =>
    link?.title?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const importantLinks = filteredLinks.filter(link => link.bool_imp);

  const handleDeleteLink = (id: string) => {
    onDeleteLink(id);
  };

  const handleToggleImportant = (id: string) => {
    onToggleImportant(id);
  };

  const handleTogglePublic = (id: string) => {
    onTogglePublic(id);
  };

  const handleShareLink = (id: string) => {
    onShareLink(id);
  };

  const handleUpdateNotes = (id: string, notes: string) => {
    onUpdateNotes(id, notes);
  };

  const handleSaveToCollection = (linkId: string, collectionId: string) => {
    onSaveToCollection(linkId, collectionId);
  };

  const handleRemoveFromCollection = (collectionId: string, linkId: string) => {
    onRemoveFromCollection(collectionId, linkId);
  };

  return (
    <div className="flex flex-col gap-4">
      <Tabs value={activeTab} onValueChange={onTabChange}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">All Links</TabsTrigger>
          <TabsTrigger value="important">Important</TabsTrigger>
          <TabsTrigger value="collections">Collections</TabsTrigger>
        </TabsList>
      </Tabs>

      <ScrollArea className="h-[calc(100vh-16rem)] md:h-[calc(100vh-12rem)] [&>div]:overflow-y-scroll [&>div]:scrollbar-none">
        <div className="space-y-4">
          {activeTab === "all" ? (
            filteredLinks.length > 0 ? (
              filteredLinks.map(link => (
                <LinkCard
                  key={link.id}
                  {...link}
                  onDelete={handleDeleteLink}
                  onToggleImportant={handleToggleImportant}
                  onTogglePublic={handleTogglePublic}
                  onShare={handleShareLink}
                  onUpdateNotes={handleUpdateNotes}
                  onSaveToCollection={(linkId, collectionId) => handleSaveToCollection(linkId, collectionId)}
                  onRemoveFromCollection={(collectionId, linkId) => handleRemoveFromCollection(collectionId, linkId)}
                />
              ))
            ) : (
              <EmptyState
                icon={<Inbox className="h-8 w-8 text-zinc-500" />}
                title="No links yet"
                description="Add your first link to get started"
                action={
                  <Button className="bg-zinc-200 text-zinc-900 hover:bg-zinc-300">
                    <LinkIcon className="h-4 w-4 mr-2" />
                    Add Link
                  </Button>
                }
              />
            )
          ) : activeTab === "important" ? (
            importantLinks.length > 0 ? (
              importantLinks.map(link => (
                <LinkCard
                  key={link.id}
                  {...link}
                  onDelete={handleDeleteLink}
                  onToggleImportant={handleToggleImportant}
                  onTogglePublic={handleTogglePublic}
                  onShare={handleShareLink}
                  onUpdateNotes={handleUpdateNotes}
                  onSaveToCollection={(linkId, collectionId) => handleSaveToCollection(linkId, collectionId)}
                  onRemoveFromCollection={(collectionId, linkId) => handleRemoveFromCollection(collectionId, linkId)}
                />
              ))
            ) : (
              <EmptyState
                icon={<Star className="h-8 w-8 text-zinc-500" />}
                title="No important links"
                description="Mark some links as important to see them here"
                action={
                  <Button className="bg-zinc-200 text-zinc-900 hover:bg-zinc-300">
                    <LinkIcon className="h-4 w-4 mr-2" />
                    Add Link
                  </Button>
                }
              />
            )
          ) : (
            Array.isArray(collections) && collections.length > 0 ? (
              collections.map(collection => (
                <div key={collection.id} className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">{collection.name}</h3>
 
                </div>
              ))
            ) : (
              <EmptyState
                icon={<BookOpen className="h-8 w-8 text-zinc-500" />}
                title="No collections yet"
                description="Create your first collection to organize your links"
                action={
                  <Button className="bg-zinc-200 text-zinc-900 hover:bg-zinc-300">
                    <FolderPlus className="h-4 w-4 mr-2" />
                    Create Collection
                  </Button>
                }
              />
            )
          )}
        </div>
      </ScrollArea>
    </div>
  );
}