import { CardDescription, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Star, ThumbsDown, Globe, Clock } from "lucide-react";

interface LinkContentProps {
  url: string;
  title: string;
  description?: string;
  tags?: string[];
  shared_with?: string[];
  bool_imp: boolean;
  isPublic: boolean;
  upvote: number;
  downvote: number;
  created_at: string;
  warning?: string;
  isEditing: boolean;
  editedNotes: string;
  showFullDescription: boolean;
  onShowMoreDescription: () => void;
  onEditNotesChange: (value: string) => void;
}

export function LinkContent({
  url,
  title,
  description,
  tags,
  shared_with,
  bool_imp,
  isPublic,
  upvote,
  downvote,
  created_at,
  warning,
  isEditing,
  editedNotes,
  showFullDescription,
  onShowMoreDescription,
  onEditNotesChange,
}: LinkContentProps) {
  return (
    <div className="space-y-4">
      <CardTitle className="text-lg font-semibold text-white">
        <a href={url} target="_blank" rel="noopener noreferrer" className="hover:underline">
          {title}
        </a>
      </CardTitle>

      {description && (
        <CardDescription className="text-sm text-white/80 line-clamp-3">
          {showFullDescription ? description : description.substring(0, 150)}
          {!showFullDescription && description.length > 150 && (
            <span className="text-blue-400 cursor-pointer hover:underline" onClick={onShowMoreDescription}>
              ... See more
            </span>
          )}
        </CardDescription>
      )}

      <div className="flex flex-wrap gap-2">
        {tags?.map((tag, index) => (
          <Badge key={index} className="bg-zinc-800 text-zinc-300">
            {tag}
          </Badge>
        ))}
      </div>

      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Star className="h-4 w-4 text-yellow-400" />
            <span className="text-sm text-white/80">{upvote}</span>
          </div>
          <div className="flex items-center gap-2">
            <ThumbsDown className="h-4 w-4 text-red-400" />
            <span className="text-sm text-white/80">{downvote}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Globe className={`h-4 w-4 ${isPublic ? 'text-green-400' : 'text-red-400'}`} />
            <span className="text-sm text-white/80">{isPublic ? 'Public' : 'Private'}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4 text-white/50" />
            <span className="text-sm text-white/50">{created_at}</span>
          </div>
        </div>
      </div>

      {warning && (
        <div className="bg-zinc-950 p-3 rounded-lg text-sm">
          <p className="text-white/50 font-medium text-xs uppercase mb-1">Warning</p>
          <p className="text-balance text-white/90">{warning}</p>
        </div>
      )}

      {isEditing && (
        <div className="mt-4">
          <Textarea
            value={editedNotes}
            onChange={(e) => onEditNotesChange(e.target.value)}
            placeholder="Add notes..."
            className="min-h-[100px]"
          />
        </div>
      )}
    </div>
  );
}
