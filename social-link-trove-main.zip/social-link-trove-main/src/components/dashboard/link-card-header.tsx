import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Globe, Lock, ChevronUp, ChevronDown, Star, X } from "lucide-react";

interface LinkCardHeaderProps {
  /**
   * The domain of the link.
   */
  domain: string;
  /**
   * Whether the link is important.
   */
  bool_imp: boolean;
  /**
   * Whether the link is public.
   */
  isPublic: boolean;
  /**
   * Whether the preview is open.
   */
  isPreviewOpen: boolean;
  /**
   * Callback function to toggle the public status of the link.
   */
  onTogglePublic: () => void;
  /**
   * Callback function to toggle the preview.
   */
  onTogglePreview: () => void;
}

export function LinkCardHeader({
  domain,
  bool_imp,
  isPublic,
  isPreviewOpen,
  onTogglePublic,
  onTogglePreview,
}: LinkCardHeaderProps) {
  return (
    <div className="px-6 py-4 border-b border-white/10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Globe className={`h-4 w-4 ${isPublic ? 'text-green-400' : 'text-red-400'}`} />
            <span className="text-sm text-white/80">{isPublic ? 'Public' : 'Private'}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star className={`h-4 w-4 ${bool_imp ? 'text-yellow-400' : 'text-white/50'}`} />
            <span className="text-sm text-white/80">{bool_imp ? 'Important' : 'Normal'}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onTogglePublic}
            className="text-white/80 hover:text-white"
          >
            {isPublic ? 'Make Private' : 'Make Public'}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onTogglePreview}
            className="text-white/80 hover:text-white"
          >
            {isPreviewOpen ? (
              <X className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
      <div className="mt-2">
        <p className="text-sm text-white/80">{domain}</p>
      </div>
    </div>
  );
}
