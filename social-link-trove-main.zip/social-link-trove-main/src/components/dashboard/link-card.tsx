import { useSelector, useDispatch } from 'react-redux';
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LinkContent } from "./link-content";
import { LinkCardActions } from "./link-card-actions";
import { LinkCardHeader } from "./link-card-header";
import { RootState } from '@/store';
import { setIsEditing, setEditedNotes, setIsSaving, setShowFullDescription, setIsPreviewOpen } from '@/store/slices/linkCardSlice';

interface LinkCardProps {
  id: string;
  url: string;
  title?: string;
  description?: string;
  tags?: string[];
  shared_with?: string[];
  bool_imp: boolean;
  isPublic: boolean;
  upvote: number;
  downvote: number;
  created_at: string;
  warning?: string;
  onDelete?: (id: string) => void;
  onToggleImportant?: (id: string, important: boolean) => void;
  onTogglePublic?: (id: string) => void;
  onShare?: (id: string) => void;
  onUpdateNotes?: (id: string, notes: string) => void;
  onSaveToCollection?: (id: string, collectionId: string) => void;
  onRemoveFromCollection?: (id: string, collectionId: string) => void;
  onEdit?: () => void;
}

export function LinkCard({
  id,
  url,
  title,
  description,
  tags,
  shared_with,
  bool_imp,
  isPublic,
  upvote,
  downvote,
  created_at,
  warning,
  onDelete,
  onToggleImportant,
  onTogglePublic,
  onShare,
  onUpdateNotes,
  onSaveToCollection,
  onRemoveFromCollection,
  onEdit,
}: LinkCardProps) {
  const dispatch = useDispatch();
  const { isEditing, editedNotes, isSaving, showFullDescription, isPreviewOpen } = useSelector((state: RootState) => state.linkCard);

  const handleSaveNotes = async () => {
    dispatch(setIsSaving(true));
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      onUpdateNotes?.(id, editedNotes);
      dispatch(setIsEditing(false));
    } catch (error) {
      console.error('Error saving notes:', error);
    } finally {
      dispatch(setIsSaving(false));
    }
  };

  const handleTogglePublic = () => {
    onTogglePublic(id);
  };

  const handleTogglePreview = () => {
    dispatch(setIsPreviewOpen(!isPreviewOpen));
  };

  const handleShowMoreDescription = () => {
    dispatch(setShowFullDescription(!showFullDescription));
  };

  const handleEditNotesChange = (value: string) => {
    dispatch(setEditedNotes(value));
  };

  return (
    <Card className="bg-zinc-900/50 border border-zinc-800">
      <div className="relative">
        <LinkCardHeader
          domain={new URL(url).hostname}
          bool_imp={bool_imp}
          isPublic={isPublic}
          isPreviewOpen={isPreviewOpen}
          onTogglePublic={handleTogglePublic}
          onTogglePreview={handleTogglePreview}
        />
      </div>

      <CardContent className="p-4">
        <LinkContent
          url={url}
          title={title}
          description={description}
          tags={tags}
          shared_with={shared_with}
          bool_imp={bool_imp}
          isPublic={isPublic}
          upvote={upvote}
          downvote={downvote}
          created_at={created_at}
          warning={warning}
          isEditing={isEditing}
          editedNotes={editedNotes}
          showFullDescription={showFullDescription}
          onShowMoreDescription={handleShowMoreDescription}
          onEditNotesChange={handleEditNotesChange}
        />
      </CardContent>

      <CardFooter className="flex flex-wrap items-center justify-between border-t border-white/10 pt-4 gap-2">
        <div className="text-xs text-white/50">
          Created at {created_at}
        </div>
        <div className="flex flex-wrap gap-2">
          <LinkCardActions
            id={id}
            bool_imp={bool_imp}
            isPublic={isPublic}
            title={title}
            onEdit={() => dispatch(setIsEditing(true))}
            onSaveToCollection={onSaveToCollection}
            onRemoveFromCollection={onRemoveFromCollection}
          />
        </div>
      </CardFooter>
    </Card>
  );
}
